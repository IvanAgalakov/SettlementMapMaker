/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.wiz.settlementmapmaker;

/**
 *
 * @author 904187003
 */
public class Obstacle extends Shape{
    public enum ObstacleType {
        
    }
    
    public void SetObstacleType(ObstacleType type) {
        
    }
}
