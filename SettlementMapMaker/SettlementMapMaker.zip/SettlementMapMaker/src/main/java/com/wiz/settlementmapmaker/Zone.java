/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.wiz.settlementmapmaker;

/**
 *
 * @author 904187003
 */
public class Zone extends Shape{
    public void setZoneType(String type) {
        
    }
    
    public String getZoneType() {
        return null;
    }
}
